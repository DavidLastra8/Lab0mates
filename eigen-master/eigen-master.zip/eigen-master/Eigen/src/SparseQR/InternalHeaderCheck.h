#ifndef EIGEN_SPARSEQR_MODULE_H
#error "Please include Eigen/SparseQR instead of including headers inside the src directory directly."
#endif
