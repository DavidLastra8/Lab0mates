#ifndef EIGEN_SPARSECORE_MODULE_H
#error "Please include Eigen/SparseCore instead of including headers inside the src directory directly."
#endif
